import { db, ref, set, push, onValue } from "./firebase-config.js";

// Add Teacher (Admin)
window.addTeacher = function () {
  const name = document.getElementById("adminTeacherName").value;
  const department = document.getElementById("adminTeacherDept").value;
  const subject = document.getElementById("adminTeacherSubject").value;
  const email = document.getElementById("adminTeacherEmail").value;

  if (!name || !department || !subject || !email) {
    alert("Please fill all teacher details");
    return;
  }

  const id = push(ref(db, "teachers")).key;
  set(ref(db, "teachers/" + id), {
    id,
    name,
    department,
    subject,
    email
  }).then(() => {
    alert("Teacher added successfully");
    loadTeachers();
  });
};

// Load Teachers (Admin)
function loadTeachers() {
  const container = document.getElementById("teacherList");
  container.innerHTML = "Loading...";

  onValue(ref(db, "teachers"), (snapshot) => {
    const data = snapshot.val();
    if (!data) return container.innerHTML = "No teachers found.";

    container.innerHTML = Object.values(data).map(t => `
      <div>
        <b>${t.name}</b> - ${t.subject} (${t.department})<br>
        ID: ${t.id}<br><hr>
      </div>
    `).join("");
  });
}
loadTeachers();

// Student Registration
window.registerStudent = function () {
  const name = document.getElementById("studentName").value;
  const email = document.getElementById("studentEmail").value;

  if (!name || !email) {
    alert("Enter name and email");
    return;
  }

  const id = push(ref(db, "students")).key;
  set(ref(db, "students/" + id), {
    id,
    name,
    email
  }).then(() => alert("Student registered successfully"));
};

// Search Teacher



window.searchTeacher = function () {
  const subject = document.getElementById("searchSubject").value.trim().toLowerCase();
  const resultsDiv = document.getElementById("searchResults");
  resultsDiv.innerHTML = "Searching...";

  const teacherRef = ref(db, "teachers");
  onValue(teacherRef, (snapshot) => {
    const data = snapshot.val();
    resultsDiv.innerHTML = ""; // Clear previous results
    let found = false;

    for (let key in data) {
      const teacher = data[key];
      if (teacher.subject && teacher.subject.toLowerCase().includes(subject)) {
        resultsDiv.innerHTML += `
          <div class="teacher-result">
            <h4>${teacher.name}</h4>
            <p><b>Subject:</b> ${teacher.subject}</p>
            <p><b>Email:</b> ${teacher.email}</p>
          </div><hr/>
        `;
        found = true;
      }
    }

    if (!found) {
      resultsDiv.innerHTML = "No matching teachers found.";
    }
  }, (error) => {
    console.error("Search failed:", error);
    resultsDiv.innerHTML = "Error loading teachers.";
  });
};


// Book Appointment (Student)
window.bookAppointment = function () {
  const teacherId = document.getElementById("appointmentTeacherId").value;
  const time = document.getElementById("appointmentTime").value;

  if (!teacherId || !time) {
    alert("Enter teacher ID and time");
    return;
  }

  const id = push(ref(db, "appointments")).key;
  set(ref(db, "appointments/" + id), {
    id,
    teacherId,
    time,
    status: "pending"
  }).then(() => alert("Appointment booked"));
};

// Teacher Login
window.loginTeacher = function () {
  const email = document.getElementById("teacherLoginEmail").value.trim().toLowerCase(); // Normalize email

  const teacherRef = ref(db, "teachers");
  onValue(teacherRef, (snapshot) => {
    const data = snapshot.val();

    if (!data) {
      alert("No teachers found.");
      return;
    }

    let matched = null;
    for (const id in data) {
      if (data[id].email && data[id].email.toLowerCase() === email) {
        matched = { id, ...data[id] };
        break;
      }
    }

    if (matched) {
      localStorage.setItem("teacherId", matched.id);
      alert("Logged in successfully!");
      // Optionally redirect or load appointments
    } else {
      alert("Teacher not found. Please check email.");
    }
  }, (error) => {
    console.error("Error reading teacher data:", error);
    alert("Login failed due to database error.");
  });
};


// View Appointments (Teacher)


window.viewAppointments = function () {
  const teacherId = localStorage.getItem("teacherId");
  const container = document.getElementById("appointmentList");

  if (!teacherId) {
    alert("You must be logged in as a teacher.");
    return;
  }

  const appointmentRef = ref(db, "appointments");

  onValue(appointmentRef, (snapshot) => {
    const data = snapshot.val();
    container.innerHTML = "";

    if (!data) {
      container.innerHTML = "No appointments found.";
      return;
    }

    let html = "";
    let hasData = false;

    Object.values(data).forEach(app => {
      if (app.teacherId === teacherId) {
        html += `
          <div class="appointment-card">
            <p><b>Student:</b> ${app.studentName}</p>
            <p><b>Subject:</b> ${app.subject}</p>
            <p><b>Date:</b> ${app.date}</p>
            <p><b>Status:</b> ${app.status || "Pending"}</p>
            <hr/>
          </div>
        `;
        hasData = true;
      }
    });

    container.innerHTML = hasData ? html : "No appointments for you.";
  }, (error) => {
    console.error("Error fetching appointments:", error);
    container.innerHTML = "Failed to load appointments.";
  });
};
