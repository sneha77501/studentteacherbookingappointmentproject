// Firebase SDK imports
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getDatabase, ref, set, push, onValue } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-database.js";

// Your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyASjKsVhQNGbk_sEdCoOMFott5K8zpEuys",
  authDomain: "student-teacher-appointm-248a4.firebaseapp.com",
  databaseURL: "https://student-teacher-appointm-248a4-default-rtdb.firebaseio.com",
  projectId: "student-teacher-appointm-248a4",
  storageBucket: "student-teacher-appointm-248a4.appspot.com",
  messagingSenderId: "930599499854",
  appId: "1:930599499854:web:fbcf8476f731aa0491eb1f"
};

// Initialize
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

export { db, ref, set, push, onValue };
